<?php
session_start();
include('db.php');

// Fungsi untuk registrasi pengguna
function registerUser($username, $password) {
    global $conn;
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $query = "INSERT INTO users (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $username, $password_hash);
    return $stmt->execute();
}

// Fungsi untuk login pengguna
function loginUser($username, $password) {
    global $conn;
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        return true;
    }
    return false;
}

// Fungsi untuk menambah tugas
function addTask($title, $description, $user_id) {
    global $conn;
    $query = "INSERT INTO tasks (title, description, user_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssi', $title, $description, $user_id);
    return $stmt->execute();
}

// Fungsi untuk mendapatkan daftar tugas
function getTasks($user_id) {
    global $conn;
    $query = "SELECT * FROM tasks WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    return $stmt->get_result();
}

// Fungsi untuk mengedit tugas
function updateTask($task_id, $title, $description) {
    global $conn;
    $query = "UPDATE tasks SET title = ?, description = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssi', $title, $description, $task_id);
    return $stmt->execute();
}

// Fungsi untuk menghapus tugas
function deleteTask($task_id) {
    global $conn;
    $query = "DELETE FROM tasks WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $task_id);
    return $stmt->execute();
}
?>
