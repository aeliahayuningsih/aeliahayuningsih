<?php
$host = 'localhost';
$username = 'root'; // Ganti dengan username DB Anda
$password = ''; // Ganti dengan password DB Anda
$dbname = 'todo_list';

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
