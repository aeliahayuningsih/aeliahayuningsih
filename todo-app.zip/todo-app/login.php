<?php
session_start();
include('includes/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<h1>Selamat Datang Di Aplikasi Todo-List</h1>
<center><h3>Kelompok : Andri Sarwono - Aelia Hayuningsih</h3></center>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* CSS untuk membuat form login terpusat */
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f9;
        }

        .login-box {
            padding: 30px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        .login-box h1 {
            margin-bottom: 20px;
        }

        .login-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        .login-box button {
            width: 100%;
            padding: 10px;
            background-color: #5c6bc0;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
        }

        .login-box button:hover {
            background-color: #3f4b88;
        }

        .login-box p {
            margin-top: 10px;
        }

        .login-box a {
            color: #5c6bc0;
            text-decoration: none;
        }

        .login-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="login-box">
            <h1>Login</h1>

            <?php if (isset($error)) echo "<p style='color: red;'>$error</p>"; ?>

            <form method="POST">
                <label for="username">Username:</label><br>
                <input type="text" name="username" required><br>
                <label for="password">Password:</label><br>
                <input type="password" name="password" required><br>
                <button type="submit">Login</button>
            </form>

            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
</body>
</html>
