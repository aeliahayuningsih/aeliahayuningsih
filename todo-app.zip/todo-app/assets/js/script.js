// Mengonfirmasi penghapusan tugas dengan pop-up
document.querySelectorAll('button[name="delete"]').forEach(button => {
    button.addEventListener('click', function(event) {
        const confirmation = confirm("Are you sure you want to delete this task?");
        if (!confirmation) {
            event.preventDefault(); // Mencegah penghapusan jika user batal
        }
    });
});

// Membuka form untuk menambah tugas baru secara dinamis
document.querySelector('#add-task-btn').addEventListener('click', function() {
    const form = document.querySelector('#add-task-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none'; // Toggle visibility
});

// Menghapus pesan kesalahan atau sukses setelah beberapa detik
setTimeout(function() {
    const alertMessages = document.querySelectorAll('.alert');
    alertMessages.forEach(function(alert) {
        alert.style.display = 'none';
    });
}, 5000); // Menghilangkan pesan setelah 5 detik
