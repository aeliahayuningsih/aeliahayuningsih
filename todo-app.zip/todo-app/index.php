<?php
include('includes/functions.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        addTask($_POST['title'], $_POST['description'], $user_id);
    } elseif (isset($_POST['update'])) {
        updateTask($_POST['task_id'], $_POST['title'], $_POST['description']);
    } elseif (isset($_POST['delete'])) {
        deleteTask($_POST['task_id']);
    }
}

$tasks = getTasks($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo List</title>
</head>
<body>
    <h1>Todo List</h1>
    <a href="logout.php">Logout</a>

    <h2>Add Task</h2>
    <form method="POST">
        <label>Title:</label><br>
        <input type="text" name="title" required><br>
        <label>Description:</label><br>
        <textarea name="description" required></textarea><br>
        <button type="submit" name="add">Add Task</button>
    </form>

    <h2>Tasks</h2>
    <table border="1">
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php while ($task = $tasks->fetch_assoc()): ?>
            <tr>
                <td><?php echo $task['title']; ?></td>
                <td><?php echo $task['description']; ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                        <button type="submit" name="delete">Delete</button>
                    </form>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                        <input type="text" name="title" value="<?php echo $task['title']; ?>" required>
                        <textarea name="description" required><?php echo $task['description']; ?></textarea>
                        <button type="submit" name="update">Update</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
